package ma.emsi.tpspringdata.repositories;

import ma.emsi.tpspringdata.entities.Seance;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeanceRepository extends JpaRepository<Seance,Integer> {
}
