package ma.emsi.tpspringdata;

import ma.emsi.tpspringdata.entities.Cours;
import ma.emsi.tpspringdata.entities.Etudiant;
import ma.emsi.tpspringdata.entities.Professeur;
import ma.emsi.tpspringdata.entities.Seance;
import ma.emsi.tpspringdata.repositories.CoursRepository;
import ma.emsi.tpspringdata.repositories.EtudiantRepository;
import ma.emsi.tpspringdata.repositories.ProfesseurRepository;
import ma.emsi.tpspringdata.repositories.SeanceRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;
import java.util.stream.Stream;

@SpringBootApplication
public class TpSpringDataApplication {

    public static void main(String[] args) {

        SpringApplication.run(TpSpringDataApplication.class, args);
    }
    @Bean
    CommandLineRunner start(CoursRepository coursRepository, ProfesseurRepository professeurRepository,
                            SeanceRepository seanceRepository, EtudiantRepository etudiantRepository ){
        return args -> {
            Stream.of("fati", "leila","hiba")
                    .forEach(fullName->{
            Etudiant etudiant= new Etudiant();
            etudiant.setRegistrationNumber(fullName );
            etudiant.setFullName(fullName);
            etudiant.setBirthay(new Date());
            etudiant.setLastConnection(new Date());
            etudiant.setStillActive(Math.random()>0.5?true:false);
            etudiant.setSeances(null);
            etudiantRepository.save(etudiant);

        });

            Stream.of("nora", "naima","malak")
                    .forEach(fullName->{
                        Professeur professeur= new Professeur();
                        professeur.setFullName(fullName);
                        professeur.setAssignementDate(new Date());
                        professeur.setCours(null);
                        professeurRepository.save(professeur);

                    });

            Stream.of("1", "2","3")
                    .forEach(Seance->{
            Seance seance= new Seance();
            seance.setDate(new Date());
            seance.setStart_time(new Date());
            seance.setEnd_time(new Date());
            seance.setCours(null);
            seance.setEtudiants(null);
            seanceRepository.save(seance);
                    });

            Stream.of("math", "physique","informatique")
                    .forEach(cour->{
                        Cours cours = new Cours();
                        cours.setTitle(cour);
                        cours.setDescription(Math.random()>0.5?"intéréssant":"long");
                        cours.setTiming(5);
                        cours.setProfesseur(null);
                        cours.setSeance(null);
                        coursRepository.save(cours);
                    });

            Cours cours1= coursRepository.findById(1).orElse(null);
            Professeur professeur1= professeurRepository.findById(1).orElse(null);
            cours1.setProfesseur(professeur1);
            coursRepository.save(cours1);

            Cours cours2= coursRepository.findById(2).orElse(null);
            Professeur professeur3= professeurRepository.findById(3).orElse(null);
            cours2.setProfesseur(professeur3);
            coursRepository.save(cours2);

            Cours cours3= coursRepository.findById(3).orElse(null);
            Professeur professeur2= professeurRepository.findById(2).orElse(null);
            cours3.setProfesseur(professeur2);
            coursRepository.save(cours3);



            Seance seance1= seanceRepository.findById(1).orElse(null);
            seance1.setCours(cours1);
            seanceRepository.save(seance1);

            Etudiant etudiant1= etudiantRepository.findById(1).orElse(null);
            if(etudiant1.getSeances()!=null) {
                etudiant1.getSeances().add(seance1);
                seance1.getEtudiants().add(etudiant1);
                etudiantRepository.save(etudiant1);
                seanceRepository.save(seance1);
            }

            etudiant1.getSeances().forEach(s->{
                System.out.println("SEANCE=>"+s.toString());
            });


    };
}}
